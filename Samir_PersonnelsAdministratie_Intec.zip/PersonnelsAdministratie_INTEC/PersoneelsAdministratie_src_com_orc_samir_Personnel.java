package com.orc.samir;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.Import;

import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Properties;

import static java.sql.DriverManager.*;

public class Personnel {


Import java.io.IOException;
Import java.sql.Connection;
Import java.sql.DriverManager;
Import java.sql.PreparedStatement;
Import java.sql.ResultSet;
Import java.sql.SQLException;
Import java.sql.Statement;

    /**
     *
     */
Import java.util.ArrayList;
Import java.util.Calendar;
Import java.util.Properties;
Import java.util.logging.Level;
Import java.util.logging.Logger;

Import stamboom.domain.Administratie;
Import stamboom.domain.Geslacht;
Import stamboom.domain.Persoon;



    public static class DatabaseMediator implements IStorageMediator {



        private Properties props;

        private Connection conn;

        public DatabaseMediator(Properties props, Connection conn) {
            this.props = props;
            this.conn = conn;
        }

        @Override

        public Administratie load() throws IOException

        {

            Administratie admin = new Administratie();

            try

            {

                initConnection();

                String query = "select * from PERSON order by NR asc";

                Statement st = conn.createStatement();

                ResultSet resultset = st.executeQuery(query);

                while(resultset.next())

                {
                    int nr = resultset.getInt("NR");

                    String vnaam = resultset.getString("VOORNAAM");

                    String[] voornaam = vnaam.split("\\s+");

                    String achternaam = resultset.getString("ACHTERNAAM");

                    String tussenvoegsels = resultset.getString("ACHTERNAAM");

                    java.sql.Date geboortedatum;
                    geboortedatum = resultset.getDate("GEBOORTEDATUM");

                    String geboorteplaats = resultset.getString("GEBOORTEPLAATS");

                    String salarisStr;
                    salarisStr = resultset.getString("SALARIS");

                    Salaris salaris;

                    switch (salarisStr)

                    {
                        case "MAN":

                            geslacht = Geslacht.MAN;

                            break;

                        case "VROUW":

                            geslacht = Geslacht.VROUW;

                            break;

                        default:

                            geslacht = Geslacht.MAN;

                    }



                    Calendar d = Calendar.getInstance();

                    d.setTime(geboortedatum);

                    admin.addPersoon(geslacht, voornaam, achternaam, tussenvoegsels, d, geboorteplaats, null);

                }



                query = "select * from GEZIN order by NR asc";

                st = conn.createStatement();

                resultset = st.executeQuery(query);



                while(resultset.next())

                {

                    int o1 = resultset.getInt("OUDER1");

                    int o2 = resultset.getInt("OUDER2");



                    Persoon ouder1 = admin.getPersoon(o1);

                    Persoon ouder2 = admin.getPersoon(o2);



                    boolean huwelijk=false;

                    java.sql.Date huwelijksdatum = resultset.getDate("HUWELIJKSDATUM");

                    if(!resultset.wasNull())

                        huwelijk = true;


                    boolean scheiding=false;

                    java.sql.Date scheidingsdatum = resultset.getDate("SCHEIDINGSDATUM");

                    if(!resultset.wasNull())

                        scheiding = true;

                    Gezin g = admin.addOngehuwdGezin(ouder1, ouder2);

                    if(huwelijk)

                    {
                        Calendar hdatum;
                        hdatum = Calendar.getInstance();

                        hdatum.setTime(huwelijksdatum);

                        admin.setHuwelijk(g, hdatum);

                    }

                    if(scheiding)

                    {

                        Calendar sdatum = Calendar.getInstance();

                        sdatum.setTime(scheidingsdatum);

                        admin.setScheiding(g, sdatum);

                    }

                }



                query = "select * from PERSOON where OUDERLIJKGEZIN is not null";

                st = conn.createStatement();

                resultset = st.executeQuery(query);



                while(resultset.next())

                {

                    int nr = resultset.getInt("NR");

                    int gezinnr = resultset.getInt("OUDERLIJKGEZIN");

                    Persoon kind = admin.getPersoon(nr);

                    Gezin ouders = admin.getGezin(gezinnr);

                    admin.setOuders(kind, ouders);

                }

            }

            catch (SQLException ex)

            {

                Logger.getLogger(DatabaseMediator.class.getName()).log(Level.SEVERE, null, ex);

            }

            return admin;

        }



        public void save(Administratie admin) throws IOException, SQLException {

            try {



                initConnection();



//Clear the whole database

                String query = "DELETE FROM PERSOON";

                Statement st = conn.createStatement();

                st.execute(query);

                query = "DELETE FROM GEZIN";

                st.execute(query);



                ArrayList<PreparedStatement> queries = new ArrayList<>();

                String preparedQuery = "INSERT INTO PERSON(VOORNAMEN,FAMILIENAAM, TELEFOONNUMMER, TELEFOONNUMMER ICE, GEBOORTDATUM, SALARIS) values (?,?,?,?,?,?)";



//Fill list of preparedstatements with all the Persons

                for (Persoon p : admin.getPersonen())

                {

                    PreparedStatement ps = conn.prepareStatement(preparedQuery);

                    ps.setInt(1, p.getNr());

                    ps.setString(2, p.getVoornaam());

                    if(p.getTussenvoegsel() == null){

                        ps.setString(3, "");

                    }

                    else{

                        ps.setString(3, p.getTussenvoegsel());

                    }

                    ps.setString(4, p.getFamilienaam());



                    java.sql.Date date = convertJavaDateToSqlDate(p.getGebDat().getTime()); //>_>

                    ps.setDate(5, date);



                    ps.setString(6, p.getVerjaardag());

                    if(p.getOuderlijkGezin() != null){

                        ps.setInt(7, p.getOuderlijkGezin().getNr());

                    }

                    else{

                        ps.setNull(7, java.sql.Types.INTEGER);

                    }

                    if(p.getSalaris() != null){

                        ps.setString(8, p.getSalaris().toString());

                    }



                }



                preparedQuery= "INSERT INTO PROJECT(STARTDATUM, BESCHRIJVING, PRIJS, VERWACHTTE EINDDATUM) values (?,?,?,?,?)";

                for(Project g : admin.getProject())

                {

                    PreparedStatement ps = conn.prepareStatement(preparedQuery);

                    ps.setInt(1, g.getStartdatum());

                    ps.setInt(2, g.getBeschrijving().getStartdatum());

                    if(g.getPrijs() != null)

                        ps.setInt(3, g.getPrijs().getStartdatum());

                    else

                        ps.setNull(3, java.sql.Types.INTEGER);

                    if(g.getVerwachtteeinddatum() != null)

                    {

                        java.sql.Date date = convertJavaDateToSqlDate(g.getStartdatum().getTime());

                        ps.setDate(4, date);

                    }

                    else

                        ps.setNull(4, java.sql.Types.DATE);

                    if(g.getVerwachtteeinddatum() != null)

                    {

                        java.sql.Date date = convertJavaDateToSqlDate(g.getVerwachtteeinddatum().getTime());

                        ps.setDate(4, date);

                    }

                    else

                        ps.setNull(5, java.sql.Types.DATE);

                    queries.add(ps);



                }



//Execute the prepared statements to save all the Persons

                for(PreparedStatement ps: queries)
                    try {

                        switch (ps.executeUpdate()) {
                            default:
                                throw new IllegalStateException("Unexpected value: " + ps.executeUpdate());
                        }

                    } finally {

                        conn.commit();

                    }

            }catch (SQLException | SQLException ex) {

                Logger.getLogger(DatabaseMediator.class.getName()).log(Level.SEVERE, null, ex);

            }

        }



        public java.sql.Date convertJavaDateToSqlDate(java.util.Date date)

        {

            return new java.sql.Date(date.getTime());

        }



        /**

         * Laadt de instellingen, in de vorm van een Properties bestand, en controleert

         * of deze in de correcte vorm is, en er verbinding gemaakt kan worden met

         * de database.

         * @param props

         * @return

         */

        @Override

        public final boolean configure(Properties props) {

            this.props = props;

            if (!isCorrectlyConfigured()) {

                System.err.println("props mist een of meer keys");

                return false;

            }



            try {

                initConnection();

                return true;

            } catch (SQLException ex) {

                System.err.println(ex.getMessage());

                this.props = null;

                return false;

            } finally {

                closeConnection();

            }

        }



        @Override

        public Properties config() {

            return props;

        }

        @Override

        public boolean isCorrectlyConfigured() {

            if (props == null) {

                return false;

            }

            if (!props.containsKey("driver")) {

                return false;

            }

            if (!props.containsKey("url")) {

                return false;

            }

            if (!props.containsKey("username")) {

                return false;

            }

            if (!props.containsKey("password")) {

                return false;

            }

            return true;

        }



        private void initConnection() throws SQLException {

            registerDriver(new oracle.jdbc.driver.OracleDriver());

            conn = getConnection("");

        }



        private void closeConnection() {

            try {

                conn.close();

                conn = null;

            } catch (SQLException ex) {

                System.err.println(ex.getMessage());

            }

        }

    }


}
