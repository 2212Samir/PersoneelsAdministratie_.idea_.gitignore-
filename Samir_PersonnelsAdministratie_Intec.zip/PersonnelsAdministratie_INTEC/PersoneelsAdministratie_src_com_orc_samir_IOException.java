package com.orc.samir;

public class IOException extends Exception {
}
