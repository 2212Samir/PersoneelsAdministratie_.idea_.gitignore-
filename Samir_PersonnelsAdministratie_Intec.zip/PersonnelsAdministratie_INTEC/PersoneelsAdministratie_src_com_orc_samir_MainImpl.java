package com.orc.samir;

public class MainImpl extends Main {
}
